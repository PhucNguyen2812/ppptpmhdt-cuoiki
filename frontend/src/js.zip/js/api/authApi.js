import { apiFetch } from "../api/baseApi.js";
import { saveAccessToken, removeAccessToken, getAccessToken } from "../utils/token.js";
import { API_BASE_URL } from "../config.js";

export async function register(hoTen, email, matKhau, soDienThoai = null) {
  const res = await fetch(`${API_BASE_URL}v1/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include", // send refreshToken cookie
    body: JSON.stringify({ 
      hoTen: hoTen, 
      email: email, 
      matKhau: matKhau,
      soDienThoai: soDienThoai || null
    }),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.message || "Đăng ký thất bại");
  }

  const data = await res.json();
  if (data.data && data.data.accessToken) {
    saveAccessToken(data.data.accessToken);
  }
  return data;
}

export async function login(email, matKhau) {
  const res = await fetch(`${API_BASE_URL}v1/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include", // send refreshToken cookie
    body: JSON.stringify({ email: email, matKhau: matKhau }),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.message || "Đăng nhập thất bại");
  }

  const data = await res.json();
  if (data.accessToken) {
    saveAccessToken(data.accessToken);
  } else if (data.data && data.data.accessToken) {
    saveAccessToken(data.data.accessToken);
  }
  return data;
}

export async function logout() {
  try {
    // Call logout API
    await apiFetch("v1/auth/logout", { method: "POST" });
  } catch (error) {
    console.error("Logout error:", error);
  } finally {
    // Clean up local storage
    removeAccessToken();
    
    // Clear all session storage
    sessionStorage.clear();
    
    // Clear browser cache for this origin (if supported)
    if ('caches' in window) {
      caches.keys().then(names => {
        names.forEach(name => caches.delete(name));
      });
    }
    
    // Force reload and redirect to login
    // Using replace to prevent back button issues
    window.location.replace("login.html");
  }
}

/**
 * Check if user is authenticated
 * Redirect to login if not authenticated
 */
export function requireAuth() {
  const token = getAccessToken();
  
  if (!token) {
    window.location.replace("login.html");
    return false;
  }
  
  // Check if token is expired
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const exp = payload.exp * 1000; // Convert to milliseconds
    
    if (Date.now() >= exp) {
      removeAccessToken();
      window.location.replace("login.html");
      return false;
    }
  } catch (error) {
    console.error("Invalid token:", error);
    removeAccessToken();
    window.location.replace("login.html");
    return false;
  }
  
  return true;
}

/**
 * Check if user is authenticated (without redirect)
 */
export function isAuthenticated() {
  const token = getAccessToken();
  
  if (!token) {
    return false;
  }
  
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const exp = payload.exp * 1000;
    return Date.now() < exp;
  } catch (error) {
    return false;
  }
}